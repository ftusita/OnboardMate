package com.example.ondboard

data class Lesson(
    val title: String,
    val description: String,
    val imageResId: Int
)