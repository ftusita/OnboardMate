pluginManagement {
    repositories {
        google {
            content {
                includeGroupByRegex("com\\.android.*")
                includeGroupByRegex("com\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        google()
        mavenCentral()
        gradlePluginPortal()
        maven { url = uri("https://jitpack.io") } // Repositório Jitpack
        maven { url = uri("https://repositories.cloud.ibm.com/artifactory/api/public") } // Repositório IBM Cloud
        maven { url = uri("https://repo1.maven.org/maven2/") }  // Repositório para SDKs da IBM
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        maven { url = uri("https://jitpack.io") } // Repositório Jitpack
        maven { url = uri("https://repositories.cloud.ibm.com/artifactory/api/public") } // Repositório IBM Cloud
    }
}

rootProject.name = "ondboard"
include(":app")
