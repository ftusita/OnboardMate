plugins {
    id("com.android.application")
    id("kotlin-android")
    id("com.google.gms.google-services")  // Plugin para Google Services
}

android {
    namespace = "com.example.ondboard"
    compileSdk = 33

    defaultConfig {
        applicationId = "com.example.ondboard"
        minSdk = 21
        targetSdk = 33
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }

    kotlinOptions {
        jvmTarget = "1.8"
    }
}

dependencies {
    // Dependências padrão do Android
    implementation("androidx.core:core-ktx:1.10.1")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.9.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.activity:activity-ktx:1.7.2")

    // OkHttp para requisições HTTP
    implementation("com.squareup.okhttp3:okhttp:4.9.3")

    // Gson para conversão de JSON
    implementation("com.google.code.gson:gson:2.8.9")

    // Firebase Authentication e Firebase Database
    implementation(platform("com.google.firebase:firebase-bom:32.2.0")) // Versão do BoM pode variar
    implementation("com.google.firebase:firebase-auth")  // Firebase Authentication
    implementation("com.google.firebase:firebase-database")  // Firebase Realtime Database

    // IBM Watson Assistant SDK
    implementation("com.ibm.watson:assistant:12.0.0") // Dependência do Watson Assistant

    implementation("com.ibm.cloud:sdk-core:9.21.1") //Dependência do SDK Core da IBM

    // Dependências de teste
    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.1.5")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.5.1")
}
