package com.example.ondboard

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.ImageButton
import android.widget.MediaController
import android.widget.VideoView
import androidx.appcompat.app.AppCompatActivity


class VideoPlayerActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_video_player)

        // Inicialize o VideoView
        val videoView: VideoView = findViewById(R.id.video_view)

        // Crie o URI para o vídeo que está na pasta raw
        val videoUri = Uri.parse("android.resource://" + packageName + "/" + R.raw.eurofarma)

        // Associe o vídeo ao VideoView
        videoView.setVideoURI(videoUri)

        // Adicione controles de mídia (play, pause, etc.)
        val mediaController = MediaController(this)
        videoView.setMediaController(mediaController)
        mediaController.setAnchorView(videoView)

        // Inicie a reprodução quando o vídeo estiver preparado
        videoView.setOnPreparedListener { mediaPlayer ->
            mediaPlayer.setOnVideoSizeChangedListener { _, _, _ ->
                videoView.start()  // Inicia a reprodução
            }
        }

        // Configura o botão de voltar para redirecionar para a TrainingActivity
        val backButton: ImageButton = findViewById(R.id.back_button)
        backButton.setOnClickListener {
            val intent = Intent(this, TrainingActivity::class.java)
            startActivity(intent)
            finish()  // Encerra a VideoPlayerActivity
        }
    }
}