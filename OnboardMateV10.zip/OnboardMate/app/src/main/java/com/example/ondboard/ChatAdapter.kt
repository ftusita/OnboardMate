package com.example.ondboard

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ChatAdapter(private val messageList: List<Message>) : RecyclerView.Adapter<ChatAdapter.MessageViewHolder>() {

    inner class MessageViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val messageTextView: TextView = itemView.findViewById(R.id.message_text)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MessageViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_message, parent, false)
        return MessageViewHolder(view)
    }

    override fun onBindViewHolder(holder: MessageViewHolder, position: Int) {
        val message = messageList[position]
        holder.messageTextView.text = message.text

        // Diferencia as mensagens do usuário e do chatbot
        if (message.sentByUser) {
            holder.messageTextView.textAlignment = View.TEXT_ALIGNMENT_TEXT_END // Alinha à direita
        } else {
            holder.messageTextView.textAlignment = View.TEXT_ALIGNMENT_TEXT_START // Alinha à esquerda
        }
    }

    override fun getItemCount(): Int {
        return messageList.size
    }


}

data class Message(
    val text: String,
    val sentByUser: Boolean // true se for enviada pelo usuário, false se for resposta do chatbot
)

