package com.example.ondboard


import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class LessonAdapter(private val lessonList: List<Lesson>) :
    RecyclerView.Adapter<LessonAdapter.LessonViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LessonViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_lesson, parent, false)
        return LessonViewHolder(view)
    }

    override fun onBindViewHolder(holder: LessonViewHolder, position: Int) {
        val lesson = lessonList[position]
        holder.lessonTitle.text = lesson.title
        holder.lessonDescription.text = lesson.description
        holder.lessonImage.setImageResource(lesson.imageResId)
    }

    override fun getItemCount(): Int = lessonList.size

    inner class LessonViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val lessonImage: ImageView = itemView.findViewById(R.id.lesson_image)
        val lessonTitle: TextView = itemView.findViewById(R.id.lesson_title)
        val lessonDescription: TextView = itemView.findViewById(R.id.lesson_description)
    }
}
