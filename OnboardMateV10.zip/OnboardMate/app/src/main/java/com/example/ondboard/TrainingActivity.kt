package com.example.ondboard

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity


class TrainingActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_training)

        // Inicialize o botão Assistir
        val watchButton: Button = findViewById(R.id.watch_button)
        watchButton.setOnClickListener {
            val intent = Intent(this, VideoPlayerActivity::class.java)
            startActivity(intent)
        }

        // Inicialize os botões da barra de navegação inferior
        val homeButton: ImageButton = findViewById(R.id.home_button)
        val progressButton: ImageButton = findViewById(R.id.progress_button)
        val chatButton: ImageButton = findViewById(R.id.chat_button)
        val userButton: ImageButton = findViewById(R.id.user_button)

        // Adicione redirecionamento aos botões
        homeButton.setOnClickListener {
            val intent = Intent(this, TrainingActivity::class.java)
            startActivity(intent)
        }

        progressButton.setOnClickListener {
            val intent = Intent(this, ProgressActivity::class.java)
            startActivity(intent)
        }

        chatButton.setOnClickListener {
            val intent = Intent(this, ChatActivity::class.java)
            startActivity(intent)
        }

        userButton.setOnClickListener {
            val intent = Intent(this, UserActivity::class.java)
            startActivity(intent)
        }
    }
}
