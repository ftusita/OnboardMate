package com.example.ondboard

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.ibm.cloud.sdk.core.http.ServiceCallback
import com.ibm.watson.assistant.v2.Assistant
import com.ibm.watson.assistant.v2.model.*
import com.ibm.cloud.sdk.core.security.IamAuthenticator

class ChatActivity : AppCompatActivity() {

    private val assistantApiKey = "i17cGZ5tVjfTKB-JbDeUPuLMGX6kCG_4cNZ_kX_AAtOb"
    private val assistantUrl = "https://api.au-syd.assistant.watson.cloud.ibm.com/instances/c5245b77-5240-4853-9614-a5f46a56819e"  // URL da API do Watson Assistant
    private val assistantId = "f5c6e164-521a-46ae-8169-ca069e7e8260"

    private lateinit var assistant: Assistant
    private lateinit var chatAdapter: ChatAdapter
    private val messageList = mutableListOf<Message>()
    private lateinit var sessionId: String
    private lateinit var sendButton: ImageButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)

        // Inicialize os componentes de interação com o chatbot
        val userInput: EditText = findViewById(R.id.user_input)
        sendButton = findViewById(R.id.send_button)

        // Desabilitar o botão de envio até que o Watson Assistant esteja pronto
        sendButton.isEnabled = false

        // Inicializar IBM Watson Assistant
        initializeWatsonAssistant()

        // Inicialize o RecyclerView e o adapter
        val recyclerView: RecyclerView = findViewById(R.id.recycler_view_messages)
        chatAdapter = ChatAdapter(messageList)
        recyclerView.adapter = chatAdapter
        recyclerView.layoutManager = LinearLayoutManager(this)

        // Listener para enviar a mensagem
        sendButton.setOnClickListener {
            val userMessage = userInput.text.toString()
            if (userMessage.isNotEmpty()) {
                // Adiciona a mensagem do usuário na lista e atualiza o RecyclerView
                messageList.add(Message(userMessage, true))
                chatAdapter.notifyItemInserted(messageList.size - 1)
                recyclerView.smoothScrollToPosition(messageList.size - 1)
                userInput.text.clear()

                // Envia a mensagem para o Watson Assistant e espera a resposta
                sendMessageToWatson(userMessage) { responseText ->
                    runOnUiThread {
                        // Adiciona a resposta do chatbot na lista e atualiza o RecyclerView
                        messageList.add(Message(responseText, false))
                        chatAdapter.notifyItemInserted(messageList.size - 1)
                        recyclerView.smoothScrollToPosition(messageList.size - 1)
                    }
                }
            }
        }

        // Inicialização da navegação (opcional)
        configureNavigation()
    }

    // Inicializar o Watson Assistant
    private fun initializeWatsonAssistant() {
        val authenticator = IamAuthenticator(assistantApiKey)
        assistant = Assistant("2023-06-15", authenticator)
        assistant.setServiceUrl(assistantUrl)

        // Criar uma sessão com o Watson Assistant
        val sessionOptions = CreateSessionOptions.Builder(assistantId).build()
        assistant.createSession(sessionOptions).enqueue(object : ServiceCallback<SessionResponse> {
            override fun onResponse(response: com.ibm.cloud.sdk.core.http.Response<SessionResponse>) {
                sessionId = response.getResult().sessionId
                // Habilitar o botão de envio após a sessão ser criada
                runOnUiThread {
                    sendButton.isEnabled = true
                }
            }

            override fun onFailure(e: Exception) {
                Log.e("WatsonAssistant", "Erro ao criar sessão: ${e.message}", e)
                runOnUiThread {
                    Toast.makeText(this@ChatActivity, "Falha ao criar sessão: ${e.message}", Toast.LENGTH_LONG).show()
                    sendButton.isEnabled = false  // Desabilitar o botão caso falhe
                }
            }
        })
    }

    // Função para enviar mensagem ao Watson Assistant
    private fun sendMessageToWatson(message: String, callback: (String) -> Unit) {
        if (!::sessionId.isInitialized) {
            callback("Sessão não inicializada. Aguarde a conexão.")
            return
        }

        val messageInput = MessageInput.Builder()
            .messageType("text")
            .text(message)
            .build()

        val messageOptions = MessageOptions.Builder(assistantId, sessionId)
            .input(messageInput)
            .build()

        assistant.message(messageOptions).enqueue(object : ServiceCallback<StatefulMessageResponse> {
            override fun onResponse(response: com.ibm.cloud.sdk.core.http.Response<StatefulMessageResponse>) {
                val watsonResponse = response.getResult().output.generic.firstOrNull()?.text() ?: "Nenhuma resposta disponível"
                callback(watsonResponse)
            }

            override fun onFailure(e: Exception) {
                Log.e("WatsonAssistant", "Erro ao enviar mensagem: ${e.message}", e)
                callback("Erro ao se comunicar com o chatbot: ${e.message}")
            }
        })
    }

    // Função para configurar a navegação
    private fun configureNavigation() {
        val homeButton: ImageButton = findViewById(R.id.home_button)
        val progressButton: ImageButton = findViewById(R.id.progress_button)
        val chatButton: ImageButton = findViewById(R.id.chat_button)
        val userButton: ImageButton = findViewById(R.id.user_button)

        homeButton.setOnClickListener {
            val intent = Intent(this, TrainingActivity::class.java)
            startActivity(intent)
        }

        progressButton.setOnClickListener {
            val intent = Intent(this, ProgressActivity::class.java)
            startActivity(intent)
        }

        chatButton.setOnClickListener {
            // Evita abrir a mesma página se já estiver nela
            if (this !is ChatActivity) {
                val intent = Intent(this, ChatActivity::class.java)
                startActivity(intent)
            }
        }

        userButton.setOnClickListener {
            val intent = Intent(this, UserActivity::class.java)
            startActivity(intent)
        }
    }
}
