package com.example.ondboard

import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class ProgressActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: LessonAdapter
    private lateinit var lessonList: List<Lesson>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_progress)

        recyclerView = findViewById(R.id.recycler_view)
        recyclerView.layoutManager = LinearLayoutManager(this)

        lessonList = listOf(
            Lesson("Bem vindo à Eurofarma! ", "Bem vindo! Conheça um pouco mais sobre nossa cultura, valores e o que esperamos de você.", R.drawable.video),
            Lesson("Estrutura e processos da Eurofarma", "História, missão, visão, e valores da empresa, além de uma visão geral das principais áreas e equipes.", R.drawable.aula2)
        )

        // Inicialize os botões da barra de navegação inferior
        val homeButton: ImageButton = findViewById(R.id.home_button)
        val progressButton: ImageButton = findViewById(R.id.progress_button)
        val chatButton: ImageButton = findViewById(R.id.chat_button)
        val userButton: ImageButton = findViewById(R.id.user_button)

        // Adicione redirecionamento aos botões
        homeButton.setOnClickListener {
            val intent = Intent(this, TrainingActivity::class.java)
            startActivity(intent)
        }

        progressButton.setOnClickListener {
            val intent = Intent(this, ProgressActivity::class.java)
            startActivity(intent)
        }

        chatButton.setOnClickListener {
            val intent = Intent(this, ChatActivity::class.java)
            startActivity(intent)
        }

        userButton.setOnClickListener {
            val intent = Intent(this, UserActivity::class.java)
            startActivity(intent)
        }
        adapter = LessonAdapter(lessonList)
        recyclerView.adapter = adapter

    }
}